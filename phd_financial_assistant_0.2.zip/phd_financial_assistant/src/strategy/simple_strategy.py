# Example: 3-ETF allocation strategy
