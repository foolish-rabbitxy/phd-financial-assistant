# Track portfolio, compute performance metrics
