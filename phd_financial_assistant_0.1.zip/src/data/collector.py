# Pull data from Alpaca or Yahoo Finance
